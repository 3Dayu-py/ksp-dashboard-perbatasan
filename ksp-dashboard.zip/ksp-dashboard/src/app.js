import { DATA } from './data.js';
import { initCharts, updateCharts } from './charts.js';
import { renderTable, applyFilters, resetFilters } from './table.js';
import { initModal } from './modal.js';

// ─── GLOBAL STATE ──────────────────────────────────────────────────────────
export const state = {
  filtered: [...DATA.tableData],
  sortKey: '',
  sortDir: 1,
  currentPage: 1,
  perPage: 25,
};

// ─── BOOT ──────────────────────────────────────────────────────────────────
function boot() {
  // KPI Cards
  document.getElementById('kpi-ra').textContent    = DATA.stats.totalRA.toLocaleString('id');
  document.getElementById('kpi-isu').textContent   = DATA.stats.totalIsu;
  document.getElementById('kpi-prog').textContent  = DATA.stats.totalProg;
  document.getElementById('kpi-multi').textContent = DATA.stats.totalMulti;
  document.getElementById('kpi-header').textContent = DATA.stats.totalRA.toLocaleString('id');

  // Charts
  initCharts(DATA.stats);

  // Table
  renderTable(state);

  // Modal
  initModal(DATA.tableData);

  // Filter listeners
  ['f-search', 'f-wkp', 'f-sumber', 'f-tahun', 'f-instansi'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input',  () => applyFilters(state, DATA.tableData));
    el.addEventListener('change', () => applyFilters(state, DATA.tableData));
  });

  document.getElementById('btn-reset').addEventListener('click', () =>
    resetFilters(state, DATA.tableData)
  );

  // Sort header buttons
  document.querySelectorAll('[data-sort]').forEach(th => {
    th.addEventListener('click', () => {
      const key = th.dataset.sort;
      if (state.sortKey === key) state.sortDir *= -1;
      else { state.sortKey = key; state.sortDir = 1; }
      state.currentPage = 1;
      renderTable(state);
    });
  });

  // Animate KPI counters
  animateCounters();
}

function animateCounters() {
  document.querySelectorAll('.kpi-val[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target);
    let cur = 0;
    const step = Math.ceil(target / 40);
    const t = setInterval(() => {
      cur = Math.min(cur + step, target);
      el.textContent = cur.toLocaleString('id');
      if (cur >= target) clearInterval(t);
    }, 30);
  });
}

document.addEventListener('DOMContentLoaded', boot);

// Handle goPage from pagination buttons (dispatched by modal.js)
document.addEventListener('ksp:goPage', e => {
  const pages = Math.ceil(state.filtered.length / state.perPage);
  const p = e.detail;
  if (p < 1 || p > pages) return;
  state.currentPage = p;
  renderTable(state);
  document.querySelector('.table-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
});
