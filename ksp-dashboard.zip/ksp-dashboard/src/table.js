// table.js – Table rendering, filtering, sorting, pagination

// ── TAG HELPERS ──────────────────────────────────────────────────────────
const WKP_CLASS = { PROV: 'tag-prov', 'WKP I': 'tag-wkp1', 'WKP II': 'tag-wkp2', 'WKP III': 'tag-wkp3' };

export function wkpTags(wkpStr) {
  return wkpStr.split('|').map(w => {
    w = w.trim();
    const cls = WKP_CLASS[w] || 'tag-prov';
    return `<span class="tag ${cls}">${w}</span>`;
  }).join('');
}

export function sumberTag(s) {
  if (s.includes('APBN') && s.includes('APBD')) return `<span class="tag tag-both">${s}</span>`;
  if (s.includes('APBN')) return `<span class="tag tag-apbn">${s}</span>`;
  if (s.includes('APBD')) return `<span class="tag tag-apbd">${s}</span>`;
  return `<span class="tag tag-lain">${s}</span>`;
}

function esc(s) {
  return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ── RENDER TABLE ─────────────────────────────────────────────────────────
export function renderTable(state) {
  const { filtered, currentPage, perPage } = state;
  const tbody    = document.getElementById('table-body');
  const total    = filtered.length;
  const pages    = Math.max(1, Math.ceil(total / perPage));
  const safePage = Math.min(state.currentPage, pages);
  state.currentPage = safePage;
  const start    = (safePage - 1) * perPage;
  const slice    = filtered.slice(start, start + perPage);

  // Result count
  document.getElementById('result-count').textContent =
    `${start + 1}–${Math.min(start + perPage, total)} dari ${total.toLocaleString('id')} rencana aksi`;

  // Rows
  tbody.innerHTML = slice.map((r, i) => {
    const rowClass = r.multiWkp ? 'row-merged' : (i % 2 === 0 ? 'row-even' : 'row-odd');
    const mergedBadge = r.multiWkp
      ? `<span class="badge-multi" title="Dikonsolidasi dari >1 WKP">🔗 Lintas WKP</span>`
      : '';
    return `
    <tr class="${rowClass}" data-idx="${i + start}" onclick="window.__showDetail(this.dataset.idx)">
      <td class="td-no">${start + i + 1}</td>
      <td class="td-wkp">
        <div class="tag-row">${wkpTags(r.wkp)}</div>
        ${mergedBadge}
      </td>
      <td class="td-isu"><div class="clip-2" title="${esc(r.isu)}">${esc(r.isu)}</div></td>
      <td class="td-prog"><div class="clip-2" title="${esc(r.program)}">${esc(r.program)}</div></td>
      <td class="td-ra">
        <div class="ra-text clip-2" title="${esc(r.ra)}">${esc(r.ra)}</div>
      </td>
      <td class="td-lok">
        <div class="lok-text clip-3" title="${esc(r.lokasi)}">${esc(r.lokasi)}</div>
      </td>
      <td class="td-sumber">${sumberTag(r.sumber)}</td>
      <td class="td-inst">
        <div class="clip-2" title="${esc(r.instansi)}" style="font-size:11px">${esc(r.instansi)}</div>
      </td>
      <td class="td-tahun">
        <span class="tahun-badge">${esc(r.tahun)}</span>
      </td>
    </tr>`;
  }).join('');

  renderPagination(state, pages, total);
}

// ── PAGINATION ────────────────────────────────────────────────────────────
function renderPagination(state, pages, total) {
  const pag = document.getElementById('pagination');
  const p = state.currentPage;
  let html = '';

  html += `<button class="page-btn" ${p <= 1 ? 'disabled' : ''} onclick="window.__goPage(${p - 1})">‹ Prev</button>`;

  const maxBtns = 7;
  let lo = Math.max(1, p - 3);
  let hi = Math.min(pages, lo + maxBtns - 1);
  if (hi - lo < maxBtns - 1) lo = Math.max(1, hi - maxBtns + 1);

  if (lo > 1) {
    html += `<button class="page-btn" onclick="window.__goPage(1)">1</button>`;
    if (lo > 2) html += `<span class="page-ellipsis">…</span>`;
  }
  for (let i = lo; i <= hi; i++) {
    html += `<button class="page-btn ${i === p ? 'active' : ''}" onclick="window.__goPage(${i})">${i}</button>`;
  }
  if (hi < pages) {
    if (hi < pages - 1) html += `<span class="page-ellipsis">…</span>`;
    html += `<button class="page-btn" onclick="window.__goPage(${pages})">${pages}</button>`;
  }
  html += `<button class="page-btn" ${p >= pages ? 'disabled' : ''} onclick="window.__goPage(${p + 1})">Next ›</button>`;
  html += `<span class="page-info">Hal ${p} / ${pages}</span>`;

  pag.innerHTML = html;
}

// ── FILTERS ──────────────────────────────────────────────────────────────
export function applyFilters(state, allData) {
  const q       = (document.getElementById('f-search')?.value || '').toLowerCase();
  const wkp     = document.getElementById('f-wkp')?.value     || '';
  const sumber  = document.getElementById('f-sumber')?.value  || '';
  const tahun   = document.getElementById('f-tahun')?.value   || '';
  const instansi= document.getElementById('f-instansi')?.value|| '';

  state.filtered = allData.filter(r => {
    // Text search
    if (q) {
      const hay = [r.ra, r.lokasi, r.program, r.kegiatan, r.isu, r.instansi]
        .join(' ').toLowerCase();
      if (!hay.includes(q)) return false;
    }
    // WKP
    if (wkp === 'MULTI' && !r.multiWkp) return false;
    if (wkp && wkp !== 'MULTI' && !r.wkp.includes(wkp)) return false;
    // Sumber
    if (sumber && r.sumber !== sumber) return false;
    // Tahun
    if (tahun && !r.tahun.includes(tahun.replace('–', '-').replace('–', '-'))) return false;
    // Instansi (partial match)
    if (instansi && !r.instansi.toLowerCase().includes(instansi.toLowerCase())) return false;

    return true;
  });

  // Re-apply sort
  if (state.sortKey) {
    state.filtered.sort((a, b) =>
      (a[state.sortKey] || '').localeCompare(b[state.sortKey] || '') * state.sortDir
    );
  }

  state.currentPage = 1;
  renderTable(state);
}

export function resetFilters(state, allData) {
  ['f-search', 'f-wkp', 'f-sumber', 'f-tahun', 'f-instansi'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  state.filtered  = [...allData];
  state.sortKey   = '';
  state.sortDir   = 1;
  state.currentPage = 1;
  renderTable(state);
}
