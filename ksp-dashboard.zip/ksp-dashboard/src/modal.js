// modal.js – Detail popup for each Rencana Aksi row
import { wkpTags, sumberTag } from './table.js';

function esc(s) {
  return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function lokasiBadges(lokStr) {
  if (!lokStr || lokStr === '-') return '<span style="color:var(--muted)">–</span>';
  return lokStr.split('|').map(l => l.trim()).filter(Boolean).map(l =>
    `<div class="modal-lok-item">📍 ${esc(l)}</div>`
  ).join('');
}

function detailRow(label, html, isHtml = false) {
  return `
    <div class="detail-row">
      <div class="detail-label">${label}</div>
      <div class="detail-val">${isHtml ? html : esc(html || '–')}</div>
    </div>`;
}

export function initModal(tableData) {
  const bg    = document.getElementById('modal-bg');
  const close = document.getElementById('modal-close');

  // Close on backdrop click
  bg.addEventListener('click', e => { if (e.target === bg) closeModal(); });
  close.addEventListener('click', closeModal);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

  // Expose show function globally (called from table row onclick)
  window.__showDetail = function(idx) {
    const r = tableData[parseInt(idx)];
    if (!r) return;

    document.getElementById('modal-title').textContent = r.ra;

    const isMulti = r.multiWkp;
    document.getElementById('modal-body').innerHTML = `
      ${isMulti ? `<div class="modal-multi-banner">🔗 Rencana aksi ini telah dikonsolidasi dari beberapa WKP</div>` : ''}

      <div class="detail-section">
        <div class="detail-section-title">Identitas</div>
        ${detailRow('WKP', wkpTags(r.wkp), true)}
        ${detailRow('Isu Strategis', r.isu)}
        ${detailRow('Program', r.program)}
        ${detailRow('Kegiatan', r.kegiatan)}
        ${detailRow('Kode Sub-Kegiatan', r.kodeSubkeg || '–')}
      </div>

      <div class="detail-divider"></div>

      <div class="detail-section">
        <div class="detail-section-title">Rencana Aksi & Kinerja</div>
        ${detailRow('Rencana Aksi', `<strong style="color:var(--navy);font-size:14px">${esc(r.ra)}</strong>`, true)}
        ${detailRow('Kinerja', r.kinerja)}
        ${detailRow('Indikator', r.indikator)}
      </div>

      <div class="detail-divider"></div>

      <div class="detail-section">
        <div class="detail-section-title">Lokasi Pelaksanaan</div>
        <div class="modal-lokasi">${lokasiBadges(r.lokasi)}</div>
      </div>

      <div class="detail-divider"></div>

      <div class="detail-section">
        <div class="detail-section-title">Pembiayaan & Pelaksanaan</div>
        ${detailRow('Sumber Dana', sumberTag(r.sumber), true)}
        ${detailRow('Tahun', `<span class="tahun-badge">${esc(r.tahun)}</span>`, true)}
        ${detailRow('Instansi Pelaksana', r.instansi)}
        ${detailRow('Instansi Pendukung', r.pendukung)}
      </div>
    `;

    bg.classList.add('open');
    document.body.style.overflow = 'hidden';
  };

  // Expose goPage globally (called from pagination buttons)
  window.__goPage = function(p) {
    // Imported in app.js via state — workaround via custom event
    document.dispatchEvent(new CustomEvent('ksp:goPage', { detail: p }));
  };
}

function closeModal() {
  document.getElementById('modal-bg').classList.remove('open');
  document.body.style.overflow = '';
}
