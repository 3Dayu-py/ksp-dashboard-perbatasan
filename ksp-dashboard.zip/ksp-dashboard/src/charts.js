// charts.js – All Chart.js configurations for KSP Dashboard
// Uses Chart.js 4.x loaded from CDN

const PALETTE = {
  navy:   '#0A2342',
  blue:   '#1565C0',
  sky:    '#1E88E5',
  cyan:   '#00838F',
  teal:   '#00897B',
  green:  '#2E7D32',
  amber:  '#F59E0B',
  orange: '#E65100',
  coral:  '#E53935',
  purple: '#6A1B9A',
};

// Gradient helper
function makeGrad(ctx, color1, color2, vertical = true) {
  const grad = vertical
    ? ctx.createLinearGradient(0, 0, 0, ctx.canvas.height)
    : ctx.createLinearGradient(0, 0, ctx.canvas.width, 0);
  grad.addColorStop(0, color1);
  grad.addColorStop(1, color2);
  return grad;
}

// Shared plugin: custom tooltip style
const tooltipPlugin = {
  bodyFont:  { family: 'Plus Jakarta Sans', size: 12 },
  titleFont: { family: 'Plus Jakarta Sans', size: 12, weight: '700' },
  padding: 12,
  backgroundColor: 'rgba(10,35,66,0.92)',
  borderColor: 'rgba(255,255,255,0.1)',
  borderWidth: 1,
  cornerRadius: 8,
  displayColors: true,
  boxPadding: 4,
};

const tickFont = { family: 'Plus Jakarta Sans', size: 11 };

// ── WKP DOUGHNUT ──────────────────────────────────────────────────────────
function initWkpChart(stats) {
  const ctx = document.getElementById('chart-wkp').getContext('2d');
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: Object.keys(stats.wkpCount),
      datasets: [{
        data: Object.values(stats.wkpCount),
        backgroundColor: [PALETTE.blue, PALETTE.teal, PALETTE.amber, PALETTE.coral],
        borderWidth: 3,
        borderColor: '#fff',
        hoverBorderWidth: 4,
        hoverOffset: 8,
      }],
    },
    options: {
      cutout: '65%',
      maintainAspectRatio: false,
      plugins: {
        tooltip: tooltipPlugin,
        legend: {
          position: 'bottom',
          labels: { font: tickFont, padding: 14, usePointStyle: true, pointStyleWidth: 10 },
        },
      },
      animation: { animateRotate: true, duration: 900 },
    },
  });
}

// ── SUMBER PIE ────────────────────────────────────────────────────────────
function initSumberChart(stats) {
  const ctx = document.getElementById('chart-sumber').getContext('2d');
  const cmap = {
    'APBN + APBD + Lainnya': PALETTE.blue,
    'APBN + APBD':           PALETTE.sky,
    'APBN':                  PALETTE.cyan,
    'APBD Provinsi':         PALETTE.amber,
    'APBD':                  PALETTE.orange,
    'Lainnya':               PALETTE.coral,
  };
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: Object.keys(stats.sumberData),
      datasets: [{
        data: Object.values(stats.sumberData),
        backgroundColor: Object.keys(stats.sumberData).map(k => cmap[k] || PALETTE.purple),
        borderWidth: 3, borderColor: '#fff', hoverOffset: 6,
      }],
    },
    options: {
      maintainAspectRatio: false,
      plugins: {
        tooltip: tooltipPlugin,
        legend: {
          position: 'bottom',
          labels: { font: { family: 'Plus Jakarta Sans', size: 10 }, padding: 10, usePointStyle: true },
        },
      },
      animation: { duration: 800 },
    },
  });
}

// ── TOP PROGRAM BAR (horizontal) ──────────────────────────────────────────
function initProgChart(stats) {
  const ctx = document.getElementById('chart-prog').getContext('2d');
  const items = [...stats.topProgram].reverse();
  const labels = items.map(([p]) => {
    const l = p.replace(/^PROGRAM\s+/i, '');
    return l.length > 38 ? l.slice(0, 36) + '…' : l;
  });
  const colors = items.map((_, i) => `hsl(${210 + i * 7}, 68%, ${52 + i * 1.5}%)`);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data: items.map(([, c]) => c),
        backgroundColor: colors,
        borderRadius: 5,
        borderSkipped: false,
      }],
    },
    options: {
      indexAxis: 'y',
      maintainAspectRatio: false,
      plugins: {
        tooltip: { ...tooltipPlugin, callbacks: { label: ctx => ` ${ctx.raw} rencana aksi` } },
        legend: { display: false },
      },
      scales: {
        x: { grid: { color: '#EEF3F9' }, ticks: { font: tickFont }, border: { dash: [4, 4] } },
        y: { grid: { display: false }, ticks: { font: { family: 'Plus Jakarta Sans', size: 10 } } },
      },
      animation: { delay: (ctx) => ctx.dataIndex * 40 },
    },
  });
}

// ── TOP ISU BAR (horizontal) ──────────────────────────────────────────────
function initIsuChart(stats) {
  const ctx = document.getElementById('chart-isu').getContext('2d');
  const items = [...stats.topIsu].reverse();
  const labels = items.map(([p]) => p.length > 42 ? p.slice(0, 40) + '…' : p);
  const colors = items.map((_, i) => `hsl(${155 + i * 14}, 58%, ${46 + i * 2}%)`);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data: items.map(([, c]) => c),
        backgroundColor: colors,
        borderRadius: 5,
        borderSkipped: false,
      }],
    },
    options: {
      indexAxis: 'y',
      maintainAspectRatio: false,
      plugins: {
        tooltip: { ...tooltipPlugin, callbacks: { label: ctx => ` ${ctx.raw} rencana aksi` } },
        legend: { display: false },
      },
      scales: {
        x: { grid: { color: '#EEF3F9' }, ticks: { font: tickFont }, border: { dash: [4, 4] } },
        y: { grid: { display: false }, ticks: { font: { family: 'Plus Jakarta Sans', size: 10 } } },
      },
      animation: { delay: (ctx) => ctx.dataIndex * 40 },
    },
  });
}

// ── TAHUN BAR ────────────────────────────────────────────────────────────
function initTahunChart(stats) {
  const ctx = document.getElementById('chart-tahun').getContext('2d');
  const grad = makeGrad(ctx, PALETTE.sky, PALETTE.navy);
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(stats.tahunData),
      datasets: [{
        label: 'Rencana Aksi',
        data: Object.values(stats.tahunData),
        backgroundColor: [
          PALETTE.sky, PALETTE.blue, PALETTE.navy,
          PALETTE.teal, PALETTE.cyan, '#90A4AE',
        ],
        borderRadius: 7,
        borderSkipped: false,
      }],
    },
    options: {
      maintainAspectRatio: false,
      plugins: {
        tooltip: { ...tooltipPlugin, callbacks: { label: ctx => ` ${ctx.raw} rencana aksi` } },
        legend: { display: false },
      },
      scales: {
        y: { grid: { color: '#EEF3F9' }, ticks: { font: tickFont }, border: { dash: [4, 4] } },
        x: { grid: { display: false }, ticks: { font: tickFont } },
      },
      animation: { delay: (ctx) => ctx.dataIndex * 80 },
    },
  });
}

// ── TOP INSTANSI BAR (horizontal) ─────────────────────────────────────────
function initInstansiChart(stats) {
  const ctx = document.getElementById('chart-instansi').getContext('2d');
  const items = [...stats.topInstansi].reverse();
  const labels = items.map(([p]) => {
    const short = p.replace('Dinas ','').replace('Provinsi Banten','Prov.');
    return short.length > 36 ? short.slice(0, 34) + '…' : short;
  });

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data: items.map(([, c]) => c),
        backgroundColor: items.map((_, i) => `hsl(${195 + i * 11}, 62%, ${50 + i * 1.5}%)`),
        borderRadius: 5,
        borderSkipped: false,
      }],
    },
    options: {
      indexAxis: 'y',
      maintainAspectRatio: false,
      plugins: {
        tooltip: { ...tooltipPlugin, callbacks: { label: ctx => ` ${ctx.raw} rencana aksi` } },
        legend: { display: false },
      },
      scales: {
        x: { grid: { color: '#EEF3F9' }, ticks: { font: tickFont }, border: { dash: [4, 4] } },
        y: { grid: { display: false }, ticks: { font: { family: 'Plus Jakarta Sans', size: 10 } } },
      },
      animation: { delay: (ctx) => ctx.dataIndex * 40 },
    },
  });
}

// ── PUBLIC ────────────────────────────────────────────────────────────────
export function initCharts(stats) {
  initWkpChart(stats);
  initSumberChart(stats);
  initProgChart(stats);
  initIsuChart(stats);
  initTahunChart(stats);
  initInstansiChart(stats);
}

export function updateCharts(stats) {
  // Reserved for future dynamic chart updates per filter
}
